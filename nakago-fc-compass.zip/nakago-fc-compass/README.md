# 中郷FC Compass

応援班の台数を入力して、配車交通費をスマホで計算するための簡易アプリです。

## 使い方
1. GitHubのリポジトリで「uploading an existing file」を押す
2. このフォルダ内の `index.html` と `README.md` をアップロード
3. 下の「Commit changes」を押す
4. GitHub Pagesを有効化するとスマホから開けます

## 計算ルール
- 下道：1台 1,500円
- 高速：1台 2,000円
- 片道60km超は高速判定
- 大飯：往復下道
- 丸岡・三国：敦賀IC〜鯖江IC、その後下道
